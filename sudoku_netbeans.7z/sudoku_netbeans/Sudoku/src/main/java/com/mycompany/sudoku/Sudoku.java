package com.mycompany.sudoku;

import view.SudokuView;

/**
 *
 * @author utente
 */
public class Sudoku {
    public static void main(String[] args) {
        new SudokuView().display();
    }
}

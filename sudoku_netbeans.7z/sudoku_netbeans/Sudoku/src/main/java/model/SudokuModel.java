package model;

import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author utente
 */
public class SudokuModel {
    
    private String name;
    private int seconds;
    private final static String PATH = "C:\\Work\\sudoku.csv";
    
    public void setUser(String name){
        this.name = name;
    }
    
    public void setTime(int seconds){
        this.seconds = seconds;
    }
    
    public void recordUserAndTime() throws IOException{
        try {
            FileWriter wr = new FileWriter(PATH);
            wr.write(name + ";" + seconds + ";");
            wr.flush();
            wr.close();
        } catch (IOException ex) {
            
        }
    }
  
}

package controller;

import java.io.IOException;
import java.util.Random;
import javax.swing.JTextField;
import model.SudokuModel;
import view.SudokuView;

public class SudokuController {

    private final static Random rand = new Random();
    private final static int MAX_RAND_NUM = 4;

    private JTextField[][][] textFields;
    private SudokuModel model;

    public SudokuController() {
        model = new SudokuModel();
    }

    public void randomInitialize(JTextField[][][] textFields) {
        this.textFields = textFields;

        // Inserisci numeri casuali nella griglia
        for (int region = 0; region < textFields.length; region++) {
            for (int h = 0; h < MAX_RAND_NUM; h++) {
                int row, col, num;

                do {
                    row = rand.nextInt(3);
                    col = rand.nextInt(3);
                    num = rand.nextInt(9) + 1;
                } while (!isValidMove(region, row, col, num));

                textFields[region][row][col].setText(num + "");
            }
        }

        for (int region = 0; region < textFields.length; region++) {
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    textFields[region][row][col].setEditable(false);
                }
            }
        }
    }

    public boolean isValidMove(int region, int row, int col, int num) {
        // Controlla se il numero è già presente nella riga
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if ((i != region || j != col) && textFields[i + region / 3 * 3][row][j].getText().equals(num + "")) {
                    return false;
                }
            }
        }

        // Controlla se il numero è già presente nella colonna
        for (int i = region % 3; i < 9; i += 3) {
            for (int j = 0; j < 3; j++) {
                if ((i != region || j != row) && textFields[i][j][col].getText().equals(num + "")) {
                    return false;
                }
            }
        }

        // Controlla se il numero è già presente nella griglia 3x3 (piccola)
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if ((i != region || i != row || j != col) && textFields[region][i][j].getText().equals(num + "")) {
                    return false;
                }
            }
        }

        return true;
    }

    public boolean isGameFinished() {
        for (int region = 0; region < textFields.length; region++) {
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    if (!textFields[region][row][col].isEditable()) {
                        continue;
                    }

                    String currentNumAsString = textFields[region][row][col].getText();

                    if (currentNumAsString.isBlank() || !isValidMove(region, row, col, Integer.parseInt(currentNumAsString))) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    public void clearTextFields() {
        for (int region = 0; region < textFields.length; region++) {
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    textFields[region][row][col].setText("");
                }
            }
        }

        randomInitialize(textFields);
    }

    public void enableEmptyTextFields() {
        for (int region = 0; region < textFields.length; region++) {
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    if (textFields[region][row][col].getText().isBlank()) {
                        textFields[region][row][col].setEditable(true);
                    }
                }
            }
        }
    }

    public void setUser(String name) {
        model.setUser(name);
    }

    public void setTime(int seconds) {
        model.setTime(seconds);
    }
    
    public void recordUserAndTime() throws IOException{
        model.recordUserAndTime();
    }
}
